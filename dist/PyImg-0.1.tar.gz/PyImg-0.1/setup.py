from setuptools import setup
setup(
    name="PyImg",
    version="0.1",
    py_modules=['pyimg'],
    install_requires=[
        'bs4', 
        'requests'
    ]
)
